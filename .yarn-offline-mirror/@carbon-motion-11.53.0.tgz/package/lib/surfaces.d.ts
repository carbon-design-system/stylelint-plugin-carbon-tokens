/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type DurationName, type EasingMode, type EasingName } from './tokens';
import { surfaces } from '../js/generated/surfaces.js';
export { surfaces };
/**
 * Which easing curve to use, given as token names rather than raw values.
 *
 * The parts are named instead of ordered. As a plain two item list this was
 * both harder to read — nothing told you what the second slot was for — and
 * easy to break: reformatting a hand-written Sass `(entrance expressive)` into
 * `(entrance expressive,)` quietly turns it into a list of one. Naming the
 * parts fixes both. A map means the same thing however it is formatted.
 */
interface MotionEasing {
    name: EasingName;
    mode: EasingMode;
}
type RevealKeyframe = Record<string, string | number>;
interface MotionSurfaceBase {
    duration: DurationName;
    enterEasing: MotionEasing;
    exitEasing: MotionEasing;
}
interface RevealSurface extends MotionSurfaceBase {
    kind: 'reveal';
    enter: RevealKeyframe;
    exit: RevealKeyframe;
}
interface SharedElementSurface extends MotionSurfaceBase {
    kind: 'shared-element';
    enter?: RevealKeyframe;
    exit?: RevealKeyframe;
    origin?: 'trigger';
}
export type MotionSurfaceDefinition = SharedElementSurface | RevealSurface;
export type MotionSurfaceName = keyof typeof surfaces;
/**
 * Anywhere a surface is accepted, it can be one of the built-in names or a
 * user-defined definition. Not every animation is a system-wide intent, and
 * every name in `surfaces` is public API, so a custom surface supplies a
 * definition of the same shape rather than claiming a name.
 */
export type MotionSurfaceInput = MotionSurfaceName | MotionSurfaceDefinition;
/**
 * Name a surface for error messages, so a mistake in a custom surface is not
 * reported as a problem with a built-in name.
 */
export declare const describeSurface: (surface: MotionSurfaceInput) => string;
/**
 * Author a custom surface.
 *
 * Nothing here changes the value — it is returned as given. What it buys is
 * type inference at the definition site and validation at module load rather
 * than at first animation. Assigning a bare object to `MotionSurfaceDefinition`
 * reports against the wrong union member (a `kind: 'reveal'` object is faulted
 * for not being a `SharedElementSurface`); the generic constraint here narrows
 * the literals so errors point at the property actually at fault.
 *
 * Module scope is the natural home for one, but it is not required — the React
 * adapter keys its memoization on the definition's structure rather than its
 * identity, so writing one inline in JSX is also fine.
 */
export declare const defineMotionSurface: <T extends MotionSurfaceDefinition>(definition: T) => T;
/**
 * Resolve a surface to its definition. A built-in name is looked up in the
 * generated catalog; a custom surface is validated and passed through.
 */
export declare function getMotionSurface(surface: MotionSurfaceInput): MotionSurfaceDefinition;
