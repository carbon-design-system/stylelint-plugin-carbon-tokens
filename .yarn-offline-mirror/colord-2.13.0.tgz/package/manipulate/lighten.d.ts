import { HslaColor, RgbaColor } from "../types";
export declare const lighten: (rgba: RgbaColor, amount: number, relative?: boolean | undefined) => HslaColor;
