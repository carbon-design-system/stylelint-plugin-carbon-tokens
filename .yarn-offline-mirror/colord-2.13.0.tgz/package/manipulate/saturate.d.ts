import { HslaColor, RgbaColor } from "../types";
export declare const saturate: (rgba: RgbaColor, amount: number, relative?: boolean | undefined) => HslaColor;
