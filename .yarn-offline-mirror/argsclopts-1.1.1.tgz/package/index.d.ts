export type ParseArgsConfig = import('node:util').ParseArgsConfig;
export type ParseArgsOptionsConfig = Exclude<ParseArgsConfig['options'], undefined>;
export type ParseArgsOptionConfig = ParseArgsOptionsConfig[string];
export type ArgscloptsOptions = {
    help?: string;
    helpLabel?: string;
};
export type ArgscloptsParseArgsOptionsConfig = Record<string, ArgscloptsOptions & ParseArgsOptionConfig>;
export type UsageFormatOptions = {
    lineWidth?: number | undefined;
    descriptionColumn?: number | undefined;
};
export declare function usage(options: ArgscloptsParseArgsOptionsConfig, format?: UsageFormatOptions): string;
export declare function readPkg(pkgPath: string): Promise<{
    name: string;
    version: string;
}>;
export type FormatterFunction = (arg: {
    name?: string;
    version?: string;
}) => string;
export declare function header({ pkgPath, name, headerFn, exampleFn }: {
    pkgPath?: string | undefined;
    name?: string | undefined;
    headerFn?: FormatterFunction | undefined;
    exampleFn?: FormatterFunction | undefined;
}): Promise<string>;
export declare function footer({ pkgPath, name, version, footerFn }: {
    pkgPath?: string | undefined;
    name?: string | undefined;
    version?: string | undefined;
    footerFn?: FormatterFunction | undefined;
}): Promise<string>;
export declare function formatHelpText({ options, format, pkgPath, name, version, footerFn, headerFn, exampleFn }: {
    format?: UsageFormatOptions | undefined;
    options: ArgscloptsParseArgsOptionsConfig;
    pkgPath?: string;
    name?: string;
    version?: string;
    headerFn?: FormatterFunction;
    exampleFn?: FormatterFunction;
    footerFn?: FormatterFunction;
}): Promise<string>;
export declare function printHelpText({ options, format, pkgPath, name, version, footerFn, headerFn, exampleFn }: {
    format?: UsageFormatOptions | undefined;
    options: ArgscloptsParseArgsOptionsConfig;
    pkgPath?: string;
    name?: string;
    version?: string;
    headerFn?: FormatterFunction;
    exampleFn?: FormatterFunction;
    footerFn?: FormatterFunction;
}): Promise<void>;
//# sourceMappingURL=index.d.ts.map