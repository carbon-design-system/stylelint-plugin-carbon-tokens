/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * A token set is a collection of tokens which should be along with each other.
 * For example, we have tokens that correspond to a layer level in a UI. A
 * token set allows us to group these tokens together in a way that's different
 * than their token group.
 */
import { Token } from './Token';
type TokenSetChild = Token | TokenSet;
type TokenSetDefinition = {
    name: string;
    tokens?: TokenSetChild[];
};
export declare class TokenSet {
    kind: 'TokenSet';
    name: string;
    children: TokenSetChild[];
    static create({ name, tokens }: TokenSetDefinition): TokenSet;
    constructor(name: string, tokens: TokenSetChild[]);
    [Symbol.iterator](): Generator<TokenSetChild, void, unknown>;
    getTokenSets(): TokenSet[];
    getTokenSet(name: string): TokenSet | null;
    hasToken(tokenOrName: Token | string): boolean;
}
export {};
