/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { Token } from './Token';
import { TokenFormat } from './TokenFormat';
import { TokenGroup } from './TokenGroup';
import { TokenSet } from './TokenSet';
import { group } from './v11TokenGroup';
import { set } from './v11TokenSet';
import type { TokenMetadata } from './types';
export { Token, TokenFormat, TokenGroup, TokenSet, group, set };
export declare const unstable_metadata: {
    v11: TokenMetadata[];
    v10: {
        name: string;
        type: string;
    }[];
};
