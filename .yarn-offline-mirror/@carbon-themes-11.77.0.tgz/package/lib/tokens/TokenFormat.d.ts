/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { TokenDefinition } from './types';
type TokenFormatName = 'javascript' | 'scss';
export declare const TokenFormat: {
    formats: Record<"scss" | "js", TokenFormatName>;
    convert({ name, format, }: Pick<TokenDefinition, "name"> & {
        format?: TokenFormatName;
    }): string;
};
export {};
