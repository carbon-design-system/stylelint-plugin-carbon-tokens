/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { TokenGroup } from './TokenGroup';
export declare const button: TokenGroup;
export declare const notification: TokenGroup;
export declare const tag: TokenGroup;
export declare const status: TokenGroup;
export declare const contentSwitcher: TokenGroup;
