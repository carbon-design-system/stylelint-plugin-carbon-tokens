/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * A Token is the simplest unit in our theme. It can have a name, properties
 * that it applies to like border or background, along with a state if the
 * token should only be used for specific states like hover or focus.
 */
import type { TokenDefinition, TokenProperties } from './types';
export declare class Token {
    kind: 'Token';
    name: string;
    properties?: TokenProperties;
    state?: string;
    static create(token: string | TokenDefinition): Token;
    constructor(name: string, properties?: TokenProperties, state?: string);
}
