/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { Token } from './Token';
import type { ResolvedToken, TokenContext, TokenDefinition, TokenProperties } from './types';
type TokenGroupChild = Token | TokenGroup;
type TokenGroupDefinition = {
    name: string;
    properties?: TokenProperties;
    tokens?: Array<Token | TokenDefinition | TokenGroup | string>;
};
/**
 * A TokenGroup allows us to group up a collection of tokens and nested token
 * groups. A group allows us to colocate related tokens and write information
 * once that applies to the entire collection of tokens. For example, if all the
 * tokens apply to the `border` color property then we can specify this property
 * at the group level
 *
 * A TokenGroup allows us to colocate all this information while also providing
 * ways to get information about the entire group, including properties and
 * states
 */
export declare class TokenGroup {
    kind: 'TokenGroup';
    name: string;
    properties?: TokenProperties;
    children: TokenGroupChild[];
    static create({ name, properties, tokens }: TokenGroupDefinition): TokenGroup;
    constructor(name: string, tokens: Array<Token | TokenDefinition | TokenGroup | string>, properties?: TokenProperties);
    [Symbol.iterator](): Generator<TokenGroupChild, void, unknown>;
    /**
     * Get all the tokens available in every Token Group in this TokenGroup,
     * including itself.
     */
    getTokens(parentContext?: TokenContext): ResolvedToken[];
    /**
     * Get a specific token from the TokenGroup, or form one of its nested
     * TokenGroups
     */
    getToken(tokenOrName: Token | string): Token | null;
    /**
     * Get all the unique groups in the token group, including this group
     */
    getTokenGroups(): TokenGroup[];
    /**
     * Get all the unique properties in the token group, including this group
     */
    getTokenProperties(): string[];
    /**
     * Get all the unique states in the token group, including this group
     */
    getTokenStates(): string[];
}
export {};
