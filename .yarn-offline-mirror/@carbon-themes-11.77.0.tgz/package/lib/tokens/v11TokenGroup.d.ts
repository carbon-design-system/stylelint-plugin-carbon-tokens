/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { TokenGroup } from './TokenGroup';
export declare const background: TokenGroup;
export declare const layer: TokenGroup;
export declare const field: TokenGroup;
export declare const border: TokenGroup;
export declare const text: TokenGroup;
export declare const link: TokenGroup;
export declare const icon: TokenGroup;
export declare const support: TokenGroup;
export declare const focus: TokenGroup;
export declare const skeleton: TokenGroup;
export declare const contextual: TokenGroup;
export declare const syntaxHighlight: TokenGroup;
export declare const ai: TokenGroup;
export declare const group: TokenGroup;
