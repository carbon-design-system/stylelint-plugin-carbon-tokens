/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const tokens: {
    colors: string[];
    type: string[];
    layout: readonly ["spacing01", "spacing02", "spacing03", "spacing04", "spacing05", "spacing06", "spacing07", "spacing08", "spacing09", "spacing10", "spacing11", "spacing12", "spacing13", "fluidSpacing01", "fluidSpacing02", "fluidSpacing03", "fluidSpacing04", "container01", "container02", "container03", "container04", "container05", "sizeXSmall", "sizeSmall", "sizeMedium", "sizeLarge", "sizeXLarge", "size2XLarge", "iconSize01", "iconSize02", "layout01", "layout02", "layout03", "layout04", "layout05", "layout06", "layout07"];
};
export declare const unstable__meta: {
    colors: {
        type: string;
        tokens: string[];
    }[];
    deprecated: string[];
};
