/**
 * Adjust a given token's lightness by a specified percentage
 * Example: token = hsl(10, 10, 10);
 * adjustLightness(token, 5) === hsl(10, 10, 15);
 * adjustLightness(token, -5) === hsl(10, 10, 5);
 */
export declare const adjustLightness: (token: string, shift: number) => string;
/**
 * Adjust a given token's alpha by a specified amount
 * Example: token = rgba(10, 10, 10, 1.0);
 * adjustAlpha(token, 0.3) === rgba(10, 10, 10, 0.3);
 */
export declare const adjustAlpha: (token: string, alpha: number) => string;
/**
 * Format a given token into the format expected in CSS/SCSS-based projects.
 */
export declare const formatTokenName: (token: string) => string;
