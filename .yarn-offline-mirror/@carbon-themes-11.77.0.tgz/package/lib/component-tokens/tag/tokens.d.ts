/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const tagBackgroundRed: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorRed: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverRed: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundMagenta: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorMagenta: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverMagenta: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundPurple: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorPurple: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverPurple: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundBlue: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorBlue: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverBlue: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundCyan: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorCyan: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverCyan: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundTeal: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorTeal: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverTeal: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundGreen: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorGreen: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverGreen: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundCoolGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorCoolGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverCoolGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBackgroundWarmGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagColorWarmGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagHoverWarmGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderRed: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderBlue: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderCyan: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderTeal: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderGreen: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderMagenta: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderPurple: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderCoolGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const tagBorderWarmGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
