/**
 * Copyright IBM Corp. 2025, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const contentSwitcherSelected: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const contentSwitcherBackground: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const contentSwitcherBackgroundHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
