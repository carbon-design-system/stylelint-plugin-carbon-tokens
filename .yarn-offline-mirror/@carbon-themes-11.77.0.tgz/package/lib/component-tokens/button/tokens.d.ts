/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
declare const buttonSeparator: {
    fallback: string;
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonPrimary: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonSecondary: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonTertiary: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonDangerPrimary: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonDangerSecondary: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonDangerActive: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonPrimaryActive: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonSecondaryActive: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonTertiaryActive: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonDangerHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonPrimaryHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonSecondaryHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonTertiaryHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
declare const buttonDisabled: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export { buttonSeparator, buttonPrimary, buttonSecondary, buttonTertiary, buttonDangerPrimary, buttonDangerSecondary, buttonDangerActive, buttonPrimaryActive, buttonSecondaryActive, buttonTertiaryActive, buttonDangerHover, buttonPrimaryHover, buttonSecondaryHover, buttonTertiaryHover, buttonDisabled, };
