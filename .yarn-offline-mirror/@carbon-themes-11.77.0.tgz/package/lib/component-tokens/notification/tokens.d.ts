/**
 * Copyright IBM Corp. 2022, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const notificationBackgroundError: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationBackgroundSuccess: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationBackgroundInfo: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationBackgroundWarning: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationActionHover: {
    whiteTheme: string;
    g10: string;
};
export declare const notificationActionTertiaryInverse: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationActionTertiaryInverseActive: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationActionTertiaryInverseHover: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationActionTertiaryInverseText: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const notificationActionTertiaryInverseTextOnColorDisabled: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
