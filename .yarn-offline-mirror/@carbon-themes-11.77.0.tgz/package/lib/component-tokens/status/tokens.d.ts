/**
 * Copyright IBM Corp. 2025, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const statusRed: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusOrange: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusOrangeOutline: {
    whiteTheme: string;
    g10: string;
};
export declare const statusYellow: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusYellowOutline: {
    whiteTheme: string;
    g10: string;
};
export declare const statusPurple: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusGreen: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusBlue: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusGray: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
export declare const statusAccessibilityBackground: {
    whiteTheme: string;
    g10: string;
    g90: string;
    g100: string;
};
