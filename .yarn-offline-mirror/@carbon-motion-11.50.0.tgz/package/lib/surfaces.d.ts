/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export { surfaces, getMotionSurface } from '../js/generated/surfaces.js';
import type { DurationName, EasingName, EasingMode } from './tokens';
type MotionEasing = readonly [EasingName, EasingMode];
type RevealKeyframe = Record<string, string | number>;
interface MotionSurfaceBase {
    duration: DurationName;
    enterEasing: MotionEasing;
    exitEasing: MotionEasing;
}
interface RevealSurface extends MotionSurfaceBase {
    kind: 'reveal';
    enter: RevealKeyframe;
    exit: RevealKeyframe;
}
interface SharedElementSurface extends MotionSurfaceBase {
    kind: 'shared-element';
    enter?: RevealKeyframe;
    exit?: RevealKeyframe;
    origin?: 'trigger';
}
export type MotionSurfaceDefinition = SharedElementSurface | RevealSurface;
export type MotionSurfaceName = 'disclosure' | 'contextual' | 'stretch' | 'expand' | 'invoke';
