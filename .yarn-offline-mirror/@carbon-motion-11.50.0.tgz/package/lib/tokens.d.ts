/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export { durationFast01, durationFast02, durationModerate01, durationModerate02, durationSlow01, durationSlow02, fast01, fast02, moderate01, moderate02, slow01, slow02, easings, unstable_tokens, } from '../js/generated/tokens.js';
export type DurationName = 'fast-01' | 'fast-02' | 'moderate-01' | 'moderate-02' | 'slow-01' | 'slow-02';
export type EasingName = 'standard' | 'entrance' | 'exit';
export type EasingMode = 'productive' | 'expressive';
export type CubicBezier = readonly [number, number, number, number];
export type EasingMap = Record<EasingName, Record<EasingMode, string>>;
export declare const motion: (name: EasingName, mode: EasingMode) => string;
export declare const resolveEasing: (name: EasingName, mode: EasingMode) => CubicBezier;
export declare const resolveDuration: (name: DurationName) => string;
