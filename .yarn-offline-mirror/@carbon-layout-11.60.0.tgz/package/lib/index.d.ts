/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export * from '../js/generated/layout-tokens';
import { unstable_tokens } from './tokens';
export { unstable_tokens };
export type BreakpointName = 'sm' | 'md' | 'lg' | 'xlg' | 'max';
export type Breakpoint = {
    width: string;
    columns: number;
    margin: string;
};
export type SizeName = 'XSmall' | 'Small' | 'Medium' | 'Large' | 'XLarge' | '2XLarge';
export type BorderRadiusToken = 'border-radius-00' | 'border-radius-02' | 'border-radius-04' | 'border-radius-08' | 'border-radius-16' | 'border-radius-24' | 'border-radius-max';
export declare const baseFontSize = 16;
export declare const rem: (px: number) => string;
export declare const em: (px: number) => string;
export declare const px: (value: number) => string;
export declare const breakpoints: Record<BreakpointName, Breakpoint>;
export declare const breakpointUp: (name: BreakpointName) => string;
export declare const breakpointDown: (name: BreakpointName) => string;
export declare const breakpoint: (name: BreakpointName) => string;
export declare const miniUnit = 8;
export declare const miniUnits: (count: number) => string;
export declare const spacing: string[];
export declare const fluidSpacing: (string | number)[];
export declare const layout: string[];
export declare const container: string[];
export declare const sizeXSmall: string;
export declare const sizeSmall: string;
export declare const sizeMedium: string;
export declare const sizeLarge: string;
export declare const sizeXLarge: string;
export declare const size2XLarge: string;
export declare const sizes: Record<SizeName, string>;
export declare const iconSize: string[];
export declare const borderRadius: Record<BorderRadiusToken, string>;
