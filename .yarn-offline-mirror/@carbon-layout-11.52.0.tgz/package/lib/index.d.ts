/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { unstable_tokens } from './tokens';
export { unstable_tokens };
export type BreakpointName = 'sm' | 'md' | 'lg' | 'xlg' | 'max';
export type Breakpoint = {
    width: string;
    columns: number;
    margin: string;
};
export type SizeName = 'XSmall' | 'Small' | 'Medium' | 'Large' | 'XLarge' | '2XLarge';
export declare const baseFontSize = 16;
export declare const rem: (px: number) => string;
export declare const em: (px: number) => string;
export declare const px: (value: number) => string;
export declare const breakpoints: Record<BreakpointName, Breakpoint>;
export declare const breakpointUp: (name: BreakpointName) => string;
export declare const breakpointDown: (name: BreakpointName) => string;
export declare const breakpoint: (name: BreakpointName) => string;
export declare const miniUnit = 8;
export declare const miniUnits: (count: number) => string;
export declare const spacing01: string;
export declare const spacing02: string;
export declare const spacing03: string;
export declare const spacing04: string;
export declare const spacing05: string;
export declare const spacing06: string;
export declare const spacing07: string;
export declare const spacing08: string;
export declare const spacing09: string;
export declare const spacing10: string;
export declare const spacing11: string;
export declare const spacing12: string;
export declare const spacing13: string;
export declare const spacing: string[];
export declare const fluidSpacing01 = 0;
export declare const fluidSpacing02 = "2vw";
export declare const fluidSpacing03 = "5vw";
export declare const fluidSpacing04 = "10vw";
export declare const fluidSpacing: (string | number)[];
export declare const layout01: string;
export declare const layout02: string;
export declare const layout03: string;
export declare const layout04: string;
export declare const layout05: string;
export declare const layout06: string;
export declare const layout07: string;
export declare const layout: string[];
export declare const container01: string;
export declare const container02: string;
export declare const container03: string;
export declare const container04: string;
export declare const container05: string;
export declare const container: string[];
export declare const sizeXSmall: string;
export declare const sizeSmall: string;
export declare const sizeMedium: string;
export declare const sizeLarge: string;
export declare const sizeXLarge: string;
export declare const size2XLarge: string;
export declare const sizes: Record<SizeName, string>;
export declare const iconSize01 = "1rem";
export declare const iconSize02 = "1.25rem";
export declare const iconSize: string[];
