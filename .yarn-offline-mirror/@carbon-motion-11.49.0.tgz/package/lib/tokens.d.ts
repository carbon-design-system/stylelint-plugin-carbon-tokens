/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const fast01 = "70ms";
export declare const fast02 = "110ms";
export declare const moderate01 = "150ms";
export declare const moderate02 = "240ms";
export declare const slow01 = "400ms";
export declare const slow02 = "700ms";
export declare const durationFast01 = "70ms";
export declare const durationFast02 = "110ms";
export declare const durationModerate01 = "150ms";
export declare const durationModerate02 = "240ms";
export declare const durationSlow01 = "400ms";
export declare const durationSlow02 = "700ms";
export declare const unstable_tokens: readonly ["fast01", "fast02", "moderate01", "moderate02", "slow01", "slow02", "durationFast01", "durationFast02", "durationModerate01", "durationModerate02", "durationSlow01", "durationSlow02"];
export type DurationName = 'fast-01' | 'fast-02' | 'moderate-01' | 'moderate-02' | 'slow-01' | 'slow-02';
export type EasingName = 'standard' | 'entrance' | 'exit';
export type EasingMode = 'productive' | 'expressive';
export type CubicBezier = readonly [number, number, number, number];
export type EasingMap = Record<EasingName, Record<EasingMode, string>>;
export declare const easings: EasingMap;
export declare const motion: (name: EasingName, mode: EasingMode) => string;
export declare const resolveEasing: (name: EasingName, mode: EasingMode) => CubicBezier;
export declare const resolveDuration: (name: DurationName) => string;
