/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { DurationName, EasingMode, EasingName } from './tokens';
type MotionEasing = readonly [EasingName, EasingMode];
/**
 * from/to styles for reveal surface - plain CSS property/value pairs
 * keep values engine-neutral so CSS, WAAPI, and Motion can all consume
 * them
 */
type RevealKeyframe = Record<string, string | number>;
interface MotionSurfaceBase {
    duration: DurationName;
    enterEasing: MotionEasing;
    exitEasing: MotionEasing;
}
interface RevealSurface extends MotionSurfaceBase {
    kind: 'reveal';
    enter: RevealKeyframe;
    exit: RevealKeyframe;
}
interface SharedElementSurface extends MotionSurfaceBase {
    kind: 'shared-element';
    enter?: RevealKeyframe;
    exit?: RevealKeyframe;
    origin?: 'trigger';
}
export type MotionSurfaceDefinition = SharedElementSurface | RevealSurface;
/**
 * Named motion intents. These definitions are engine and framework agnostic.
 *
 * `prefers-reduced-motion` is intentionally not represented here: surfaces
 * never animate when the users request reduced motion. Framework adapters
 * bail before running, and the Sass output is wrapped in a
 * `prefers-reduced-motion: no-preference` media query
 */
export declare const surfaces: {
    readonly disclosure: {
        readonly kind: "reveal";
        readonly duration: "moderate-01";
        readonly enter: {
            readonly blockSize: "auto";
            readonly opacity: 1;
        };
        readonly exit: {
            readonly blockSize: 0;
            readonly opacity: 0;
        };
        readonly enterEasing: readonly ["entrance", "productive"];
        readonly exitEasing: readonly ["exit", "productive"];
    };
    readonly contextual: {
        readonly kind: "reveal";
        readonly duration: "fast-02";
        readonly enter: {
            readonly opacity: 1;
            readonly transform: "scale(1)";
        };
        readonly exit: {
            readonly opacity: 0;
            readonly transform: "scale(0.96)";
        };
        readonly enterEasing: readonly ["entrance", "expressive"];
        readonly exitEasing: readonly ["exit", "expressive"];
    };
    readonly stretch: {
        readonly kind: "reveal";
        readonly duration: "slow-01";
        readonly enter: {
            readonly opacity: 1;
            readonly clipPath: "inset(0 0 0 0)";
        };
        readonly exit: {
            readonly opacity: 0;
            readonly clipPath: "inset(50% 0 50% 0)";
        };
        readonly enterEasing: readonly ["entrance", "expressive"];
        readonly exitEasing: readonly ["exit", "expressive"];
    };
    readonly expand: {
        readonly kind: "shared-element";
        readonly duration: "moderate-02";
        readonly enter: {
            readonly opacity: 1;
            readonly transform: "scale(1)";
        };
        readonly exit: {
            readonly opacity: 0;
            readonly transform: "scale(0.96)";
        };
        readonly enterEasing: readonly ["standard", "productive"];
        readonly exitEasing: readonly ["standard", "productive"];
    };
    readonly invoke: {
        readonly kind: "shared-element";
        readonly origin: "trigger";
        readonly duration: "moderate-02";
        readonly enterEasing: readonly ["standard", "expressive"];
        readonly exitEasing: readonly ["standard", "expressive"];
    };
};
export type MotionSurfaceName = keyof typeof surfaces;
export declare const getMotionSurface: (name: MotionSurfaceName) => {
    readonly kind: "reveal";
    readonly duration: "moderate-01";
    readonly enter: {
        readonly blockSize: "auto";
        readonly opacity: 1;
    };
    readonly exit: {
        readonly blockSize: 0;
        readonly opacity: 0;
    };
    readonly enterEasing: readonly ["entrance", "productive"];
    readonly exitEasing: readonly ["exit", "productive"];
} | {
    readonly kind: "reveal";
    readonly duration: "fast-02";
    readonly enter: {
        readonly opacity: 1;
        readonly transform: "scale(1)";
    };
    readonly exit: {
        readonly opacity: 0;
        readonly transform: "scale(0.96)";
    };
    readonly enterEasing: readonly ["entrance", "expressive"];
    readonly exitEasing: readonly ["exit", "expressive"];
} | {
    readonly kind: "reveal";
    readonly duration: "slow-01";
    readonly enter: {
        readonly opacity: 1;
        readonly clipPath: "inset(0 0 0 0)";
    };
    readonly exit: {
        readonly opacity: 0;
        readonly clipPath: "inset(50% 0 50% 0)";
    };
    readonly enterEasing: readonly ["entrance", "expressive"];
    readonly exitEasing: readonly ["exit", "expressive"];
} | {
    readonly kind: "shared-element";
    readonly duration: "moderate-02";
    readonly enter: {
        readonly opacity: 1;
        readonly transform: "scale(1)";
    };
    readonly exit: {
        readonly opacity: 0;
        readonly transform: "scale(0.96)";
    };
    readonly enterEasing: readonly ["standard", "productive"];
    readonly exitEasing: readonly ["standard", "productive"];
} | {
    readonly kind: "shared-element";
    readonly origin: "trigger";
    readonly duration: "moderate-02";
    readonly enterEasing: readonly ["standard", "expressive"];
    readonly exitEasing: readonly ["standard", "expressive"];
};
export {};
