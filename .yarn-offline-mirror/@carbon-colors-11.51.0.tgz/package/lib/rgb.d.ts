/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Parses a hex code string into an RGBA color string with the given opacity.
 */
export declare const rgba: (hexCode: string, opacity: number) => string;
