/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const mono = "'IBM Plex Mono', 'Menlo', 'DejaVu Sans Mono', 'Bitstream Vera Sans Mono', Courier, monospace";
export declare const sans = "'IBM Plex Sans', system-ui, -apple-system, BlinkMacSystemFont, '.SFNSText-Regular', sans-serif";
export declare const sansCondensed = "'IBM Plex Sans Condensed', 'Helvetica Neue', Arial, sans-serif";
export declare const sansHebrew = "'IBM Plex Sans Hebrew', 'Helvetica Hebrew', 'Arial Hebrew', sans-serif";
export declare const serif = "'IBM Plex Serif', 'Georgia', Times, serif";
export declare const fontFamilies: {
    mono: string;
    sans: string;
    sansCondensed: string;
    sansHebrew: string;
    serif: string;
};
export declare const fontFamily: (name: keyof typeof fontFamilies) => {
    fontFamily: string;
};
