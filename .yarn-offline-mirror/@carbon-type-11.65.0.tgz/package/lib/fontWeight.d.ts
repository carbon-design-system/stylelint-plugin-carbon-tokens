/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const light = 300;
export declare const regular = 400;
export declare const semibold = 600;
export declare const fontWeights: {
    light: number;
    regular: number;
    semibold: number;
};
export declare const fontWeight: (weight: keyof typeof fontWeights) => {
    fontWeight: number;
};
