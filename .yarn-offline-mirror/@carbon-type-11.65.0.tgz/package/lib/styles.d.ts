/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const caption01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const caption02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const label01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const label02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const helperText01: {
    fontSize: string;
    lineHeight: number;
    letterSpacing: string;
};
export declare const helperText02: {
    fontSize: string;
    lineHeight: number;
    letterSpacing: string;
};
export declare const bodyShort01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const bodyLong01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const bodyShort02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const bodyLong02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const code01: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const code02: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const heading01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const productiveHeading01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const heading02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading05: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading06: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const productiveHeading07: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const expressiveHeading01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const expressiveHeading02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const expressiveHeading03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const expressiveHeading04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
        };
    };
};
export declare const expressiveHeading05: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            letterSpacing: number;
        };
    };
};
export declare const expressiveHeading06: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
            letterSpacing: number;
        };
    };
};
export declare const expressiveParagraph01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        lg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const quotation01: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
    };
};
export declare const quotation02: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
        };
    };
};
export declare const display01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
        };
        lg: {
            fontSize: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const display02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
        };
        lg: {
            fontSize: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const display03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
    };
};
export declare const display04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        max: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
    };
};
export declare const legal01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const legal02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const bodyCompact01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const bodyCompact02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const body01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const body02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const headingCompact01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: string;
};
export declare const headingCompact02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const heading03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const heading04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const heading05: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const heading06: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const heading07: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
};
export declare const fluidHeading03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const fluidHeading04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
        };
    };
};
export declare const fluidHeading05: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            letterSpacing: number;
        };
    };
};
export declare const fluidHeading06: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
            letterSpacing: number;
        };
    };
};
export declare const fluidParagraph01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        lg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const fluidQuotation01: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            fontWeight: number;
            letterSpacing: number;
        };
        lg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        xlg: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
        max: {
            fontSize: string;
            fontWeight: number;
            lineHeight: number;
            letterSpacing: number;
        };
    };
};
export declare const fluidQuotation02: {
    fontFamily: string;
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
        };
    };
};
export declare const fluidDisplay01: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
        };
        lg: {
            fontSize: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const fluidDisplay02: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
        };
        lg: {
            fontSize: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
        };
    };
};
export declare const fluidDisplay03: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
        };
        max: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
    };
};
export declare const fluidDisplay04: {
    fontSize: string;
    fontWeight: number;
    lineHeight: number;
    letterSpacing: number;
    breakpoints: {
        md: {
            fontSize: string;
            lineHeight: number;
        };
        lg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        xlg: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
        max: {
            fontSize: string;
            lineHeight: number;
            letterSpacing: string;
        };
    };
};
