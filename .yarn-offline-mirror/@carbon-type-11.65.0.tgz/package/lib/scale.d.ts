/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const getTypeSize: (step: number) => number;
export declare const scale01 = 12;
export declare const scale02 = 14;
export declare const scale03 = 16;
export declare const scale04 = 18;
export declare const scale05 = 20;
export declare const scale06 = 24;
export declare const scale07 = 28;
export declare const scale08 = 32;
export declare const scale09 = 36;
export declare const scale10 = 42;
export declare const scale11 = 48;
export declare const scale12 = 54;
export declare const scale13 = 60;
export declare const scale14 = 68;
export declare const scale15 = 76;
export declare const scale16 = 84;
export declare const scale17 = 92;
export declare const scale18 = 102;
export declare const scale19 = 112;
export declare const scale20 = 122;
export declare const scale21 = 132;
export declare const scale22 = 144;
export declare const scale23 = 156;
/**
 * Default type scale with 23 steps.
 *
 * Generated with:
 * ```ts
 * Array.from({ length: 23 }, (_, i) => getTypeSize(i + 1))
 * ```
 */
export declare const scale: number[];
