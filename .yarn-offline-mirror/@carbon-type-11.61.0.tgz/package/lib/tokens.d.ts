/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const caption01 = "caption01";
export declare const caption02 = "caption02";
export declare const label01 = "label01";
export declare const label02 = "label02";
export declare const helperText01 = "helperText01";
export declare const helperText02 = "helperText02";
export declare const bodyShort01 = "bodyShort01";
export declare const bodyLong01 = "bodyLong01";
export declare const bodyShort02 = "bodyShort02";
export declare const bodyLong02 = "bodyLong02";
export declare const code01 = "code01";
export declare const code02 = "code02";
export declare const heading01 = "heading01";
export declare const productiveHeading01 = "productiveHeading01";
export declare const heading02 = "heading02";
export declare const productiveHeading02 = "productiveHeading02";
export declare const productiveHeading03 = "productiveHeading03";
export declare const productiveHeading04 = "productiveHeading04";
export declare const productiveHeading05 = "productiveHeading05";
export declare const productiveHeading06 = "productiveHeading06";
export declare const productiveHeading07 = "productiveHeading07";
export declare const expressiveHeading01 = "expressiveHeading01";
export declare const expressiveHeading02 = "expressiveHeading02";
export declare const expressiveHeading03 = "expressiveHeading03";
export declare const expressiveHeading04 = "expressiveHeading04";
export declare const expressiveHeading05 = "expressiveHeading05";
export declare const expressiveHeading06 = "expressiveHeading06";
export declare const expressiveParagraph01 = "expressiveParagraph01";
export declare const quotation01 = "quotation01";
export declare const quotation02 = "quotation02";
export declare const display01 = "display01";
export declare const display02 = "display02";
export declare const display03 = "display03";
export declare const display04 = "display04";
export declare const legal01 = "legal01";
export declare const legal02 = "legal02";
export declare const bodyCompact01 = "bodyCompact01";
export declare const bodyCompact02 = "bodyCompact02";
export declare const body01 = "body01";
export declare const body02 = "body02";
export declare const headingCompact01 = "headingCompact01";
export declare const headingCompact02 = "headingCompact02";
export declare const heading03 = "heading03";
export declare const heading04 = "heading04";
export declare const heading05 = "heading05";
export declare const heading06 = "heading06";
export declare const heading07 = "heading07";
export declare const fluidHeading03 = "fluidHeading03";
export declare const fluidHeading04 = "fluidHeading04";
export declare const fluidHeading05 = "fluidHeading05";
export declare const fluidHeading06 = "fluidHeading06";
export declare const fluidParagraph01 = "fluidParagraph01";
export declare const fluidQuotation01 = "fluidQuotation01";
export declare const fluidQuotation02 = "fluidQuotation02";
export declare const fluidDisplay01 = "fluidDisplay01";
export declare const fluidDisplay02 = "fluidDisplay02";
export declare const fluidDisplay03 = "fluidDisplay03";
export declare const fluidDisplay04 = "fluidDisplay04";
export declare const unstable_tokens: string[];
