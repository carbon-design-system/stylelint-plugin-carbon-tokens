/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const getTypeSize: (step: number) => number;
/**
 * Default type scale with 23 steps.
 *
 * Generated with:
 * ```ts
 * Array.from({ length: 23 }, (_, i) => getTypeSize(i + 1))
 * ```
 */
export declare const scale: number[];
