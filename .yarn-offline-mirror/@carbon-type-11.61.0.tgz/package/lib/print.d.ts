/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
type PrintableBlock = Record<string, number | string>;
export declare const print: (block: PrintableBlock) => string;
export {};
