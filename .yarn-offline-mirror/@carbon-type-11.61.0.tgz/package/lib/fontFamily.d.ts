/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export declare const fontFamilies: {
    mono: string;
    sans: string;
    sansCondensed: string;
    sansHebrew: string;
    serif: string;
};
export declare const fontFamily: (name: keyof typeof fontFamilies) => {
    fontFamily: string;
};
