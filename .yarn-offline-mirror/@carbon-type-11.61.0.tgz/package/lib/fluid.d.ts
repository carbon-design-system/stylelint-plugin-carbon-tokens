/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { BreakpointName } from '@carbon/layout';
import type { TypeStyle } from './types';
type TypeBreakpointStyles = Partial<TypeStyle>;
type TypeToken = TypeStyle & {
    breakpoints?: Partial<Record<BreakpointName, TypeBreakpointStyles>>;
};
type FluidResult = TypeStyle & Record<string, TypeBreakpointStyles | number | string | undefined>;
export declare const fluid: (selector: TypeToken) => FluidResult;
export {};
