# Cspell Types

Contains cspell types and json-schema.

This package contains no dependencies to avoid any security issues.

## Support Future Development

<!--- @@inject: ../../static/sponsor.md --->

If our spell checkers save you time, please consider supporting their development.

Please show your support through one of the following sites:

[![GitHub Sponsor](https://cspell.org/img/sponsor/github-sponsor-176px.png)](https://github.com/sponsors/streetsidesoftware) [![PayPal](https://cspell.org/img/sponsor/paypal-176px.png)](https://www.paypal.com/donate/?hosted_button_id=26LNBP2Q6MKCY) [![Open Collective](https://cspell.org/img/sponsor/open-collective-176px.png)](https://opencollective.com/cspell) [![CSpell](https://cspell.org/img/sponsor/cspell-176px.png)](https://streetsidesoftware.com/sponsor/)

<!--- @@inject-end: ../../static/sponsor.md --->

## Installation

```
npm i -S @cspell/cspell-types
```

## Usage

Can be used to make writing `cspell.config.js` files easier.

```js
'use strict';

/** @type { import("@cspell/cspell-types").CSpellUserSettings } */
const cspell = {
  description: 'cspell.config.js file in samples/js-config',
  languageSettings: [
    {
      languageId: 'cpp',
      allowCompoundWords: false,
      patterns: [
        {
          name: 'pound-includes',
          pattern: /^\s*#include.*/g
        }
      ],
      ignoreRegExpList: ['pound-includes']
    }
  ],
  dictionaryDefinitions: [
    {
      name: 'custom-words',
      path: './custom-words.txt'
    }
  ],
  dictionaries: ['custom-words']
};

module.exports = cspell;
```

## API

`CSpellSettings` (aliased as `CSpellUserSettings`) is the formal definition of the configuration that controls the spell checker.

## CSpell for Enterprise

<!--- @@inject: ../../static/tidelift.md --->

Available as part of the Tidelift Subscription.

The maintainers of cspell and thousands of other packages are working with Tidelift to deliver commercial support and maintenance for the open source packages you use to build your applications. Save time, reduce risk, and improve code health, while paying the maintainers of the exact packages you use. [Learn more.](https://tidelift.com/subscription/pkg/npm-cspell?utm_source=npm-cspell&utm_medium=referral&utm_campaign=enterprise&utm_term=repo)

<!--- @@inject-end: ../../static/tidelift.md --->

<!--- @@inject: ../../static/footer.md --->

<br/>

---

<p align="center">Brought to you by<a href="https://streetsidesoftware.com" title="Street Side Software"><img width="16" alt="Street Side Software Logo" src="https://i.imgur.com/CyduuVY.png" /> Street Side Software</a></p>

<!--- @@inject-end: ../../static/footer.md --->
