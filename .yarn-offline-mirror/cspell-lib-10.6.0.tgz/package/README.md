# CSpell Library

`cspell-lib` is the workhorse behind cspell. It does all the heavy lifting necessary to spell check files.

## Support Future Development

<!--- @@inject: ../../static/sponsor.md --->

If our tools save you time, please consider supporting their development.

Please show your support through one of the following sites:

[![GitHub Sponsor](https://streetsidesoftware.com/img/sponsor/github-sponsor-176px.png)](https://github.com/sponsors/streetsidesoftware) [![thanks.dev](https://streetsidesoftware.com/img/sponsor/thanks-dev-176px.png)](https://thanks.dev/u/gh/streetsidesoftware) [![Open Collective](https://streetsidesoftware.com/img/sponsor/open-collective-176px.png)](https://opencollective.com/cspell) [![CSpell](https://streetsidesoftware.com/img/sponsor/cspell-176px.png)](https://streetsidesoftware.com/sponsor/)

<!--- @@inject-end: ../../static/sponsor.md --->

## Installation

```
npm i -S cspell-lib
```

## Usage

### Example - Check some text

Here is an example of using `spellCheckDocument` to spell check some text with a spelling issue.

```ts
import assert from 'node:assert';

import { spellCheckDocument } from 'cspell-lib';

// cspell:ignore wordz coztom clockz cuztom
const customWords = ['wordz', 'cuztom', 'clockz'];

async function checkSpelling(phrase: string) {
  const result = await spellCheckDocument(
    { uri: 'text.txt', text: phrase, languageId: 'plaintext', locale: 'en' },
    { generateSuggestions: true, noConfigSearch: true },
    { words: customWords, suggestionsTimeout: 2000 }
  );
  return result.issues;
}

export async function run() {
  console.log(`Start: ${new Date().toISOString()}`);
  const r = await checkSpelling('These are my coztom wordz.');
  console.log(`End: ${new Date().toISOString()}`);
  // console.log(r);
  assert(r.length === 1, 'Make sure we got 1 spelling issue back.');
  assert(r[0].text === 'coztom');
  assert(r[0].suggestions?.includes('cuztom'));
  // console.log('%o', r);
}
```

### Example - Check a file

```ts
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spellCheckDocument } from 'cspell-lib';

export async function checkFile(filename: string) {
  const uri = pathToFileURL(resolve(filename)).toString();
  const result = await spellCheckDocument(
    { uri },
    { generateSuggestions: true, noConfigSearch: true },
    { words: customWords, suggestionsTimeout: 2000 }
  );
  return result.issues;
}
```

<!--- @@inject: ../../static/footer.md --->

<br/>

---

<p align="center">Brought to you by <a href="https://streetsidesoftware.com" title="Street Side Software"><img width="16" alt="Street Side Software Logo" src="https://i.imgur.com/CyduuVY.png" /> Street Side Software</a></p>

<!--- @@inject-end: ../../static/footer.md --->
