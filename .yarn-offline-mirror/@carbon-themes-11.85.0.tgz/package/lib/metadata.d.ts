/**
 * Copyright IBM Corp. 2018, 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
export type TokenMetadata = {
    name: string;
    type: 'color' | 'layout' | 'type';
};
export declare const unstable_metadata: {
    v11: TokenMetadata[];
    v10: {
        name: string;
        type: string;
    }[];
};
